// App State
let state = {
    products: JSON.parse(localStorage.getItem('luxemarket_products')) || INITIAL_PRODUCTS,
    cart: JSON.parse(localStorage.getItem('luxemarket_cart')) || [],
    wishlist: JSON.parse(localStorage.getItem('luxemarket_wishlist')) || [],
    compare: JSON.parse(localStorage.getItem('luxemarket_compare')) || [],
    currency: localStorage.getItem('luxemarket_currency') || 'BDT',
    activeCategory: 'All',
    view: 'home', // 'home', 'shop', 'wishlist', 'compare', 'checkout', 'admin'
    searchQuery: '',
    discountCode: '',
    discountAmount: 0
};

// Rates
const USD_RATE = 115; // 1 USD = 115 BDT

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    saveState();
    renderApp();
    updateBadges();
    lucide.createIcons();
});

function saveState() {
    localStorage.setItem('luxemarket_products', JSON.stringify(state.products));
    localStorage.setItem('luxemarket_cart', JSON.stringify(state.cart));
    localStorage.setItem('luxemarket_wishlist', JSON.stringify(state.wishlist));
    localStorage.setItem('luxemarket_compare', JSON.stringify(state.compare));
    localStorage.setItem('luxemarket_currency', state.currency);
}

function formatPrice(bdtAmount) {
    if (state.currency === 'USD') {
        const usd = Math.round(bdtAmount / USD_RATE);
        return `$${usd.toLocaleString()}`;
    }
    return `৳${bdtAmount.toLocaleString()}`;
}

function changeCurrency(curr) {
    state.currency = curr;
    saveState();
    renderApp();
}

function toggleDarkMode() {
    document.documentElement.classList.toggle('dark');
    const isDark = document.documentElement.classList.contains('dark');
    document.getElementById('theme-text').innerText = isDark ? 'Light Mode' : 'Dark Mode';
}

function updateBadges() {
    const cartBadge = document.getElementById('cart-badge');
    const wishBadge = document.getElementById('wishlist-badge');
    const compareBadge = document.getElementById('compare-badge');

    const cartCount = state.cart.reduce((total, item) => total + item.quantity, 0);
    if (cartCount > 0) {
        cartBadge.innerText = cartCount;
        cartBadge.classList.remove('hidden');
    } else {
        cartBadge.classList.add('hidden');
    }

    if (state.wishlist.length > 0) {
        wishBadge.innerText = state.wishlist.length;
        wishBadge.classList.remove('hidden');
    } else {
        wishBadge.classList.add('hidden');
    }

    if (state.compare.length > 0) {
        compareBadge.innerText = state.compare.length;
        compareBadge.classList.remove('hidden');
    } else {
        compareBadge.classList.add('hidden');
    }
}

function navigateTo(viewName) {
    state.view = viewName;
    window.scrollTo({ top: 0, behavior: 'smooth' });
    renderApp();
}

function filterCategory(cat) {
    state.activeCategory = cat;
    navigateTo('home');
}

// Global Search
function handleSearch(query) {
    state.searchQuery = query.toLowerCase().trim();
    const resultsContainer = document.getElementById('search-results');
    
    if (!state.searchQuery) {
        resultsContainer.classList.add('hidden');
        return;
    }

    const matches = state.products.filter(p => 
        p.name.toLowerCase().includes(state.searchQuery) || 
        p.category.toLowerCase().includes(state.searchQuery) ||
        p.brand.toLowerCase().includes(state.searchQuery)
    );

    if (matches.length === 0) {
        resultsContainer.innerHTML = `<div class="p-4 text-xs text-slate-400 text-center">No products found matching "${query}"</div>`;
    } else {
        resultsContainer.innerHTML = matches.map(p => `
            <div onclick="openQuickView(${p.id}); document.getElementById('search-results').classList.add('hidden');" class="flex items-center gap-3 p-3 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer border-b border-slate-100 dark:border-slate-700/50 last:border-none">
                <img src="${p.image}" class="w-10 h-10 object-cover rounded-lg">
                <div>
                    <div class="text-sm font-semibold text-slate-800 dark:text-slate-100">${p.name}</div>
                    <div class="text-xs text-amber-500 font-bold">${formatPrice(p.discountBDT)}</div>
                </div>
            </div>
        `).join('');
    }
    resultsContainer.classList.remove('hidden');
}

// Cart Drawer Operations
function toggleCartDrawer() {
    const overlay = document.getElementById('cart-drawer-overlay');
    const drawer = document.getElementById('cart-drawer');

    if (drawer.classList.contains('translate-x-full')) {
        drawer.classList.remove('translate-x-full');
        overlay.classList.remove('hidden');
        renderCartDrawer();
    } else {
        drawer.classList.add('translate-x-full');
        overlay.classList.add('hidden');
    }
}

function addToCart(productId) {
    const product = state.products.find(p => p.id === productId);
    if (!product || !product.inStock) return;

    const existing = state.cart.find(item => item.id === productId);
    if (existing) {
        existing.quantity += 1;
    } else {
        state.cart.push({ ...product, quantity: 1 });
    }
    saveState();
    updateBadges();
    toggleCartDrawer();
}

function updateCartQty(productId, qty) {
    if (qty <= 0) {
        state.cart = state.cart.filter(item => item.id !== productId);
    } else {
        const item = state.cart.find(i => i.id === productId);
        if (item) item.quantity = qty;
    }
    saveState();
    updateBadges();
    renderCartDrawer();
    if (state.view === 'checkout') renderApp();
}

function renderCartDrawer() {
    const container = document.getElementById('cart-drawer-items');
    const subtotalEl = document.getElementById('cart-drawer-subtotal');

    if (state.cart.length === 0) {
        container.innerHTML = `
            <div class="text-center py-12 text-slate-400">
                <i data-lucide="shopping-bag" class="w-12 h-12 mx-auto mb-3 opacity-40"></i>
                <p>Your bag is currently empty.</p>
            </div>
        `;
        subtotalEl.innerText = formatPrice(0);
        lucide.createIcons();
        return;
    }

    let subtotal = 0;
    container.innerHTML = state.cart.map(item => {
        subtotal += item.discountBDT * item.quantity;
        return `
            <div class="flex items-center gap-4 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-2xl border border-slate-100 dark:border-slate-800">
                <img src="${item.image}" class="w-16 h-16 object-cover rounded-xl">
                <div class="flex-1">
                    <h4 class="text-xs font-bold text-slate-800 dark:text-slate-100 line-clamp-1">${item.name}</h4>
                    <div class="text-amber-500 text-xs font-bold mt-1">${formatPrice(item.discountBDT)}</div>
                    <div class="flex items-center gap-2 mt-2">
                        <button onclick="updateCartQty(${item.id}, ${item.quantity - 1})" class="w-6 h-6 rounded bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-xs font-bold">-</button>
                        <span class="text-xs font-bold">${item.quantity}</span>
                        <button onclick="updateCartQty(${item.id}, ${item.quantity + 1})" class="w-6 h-6 rounded bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-xs font-bold">+</button>
                    </div>
                </div>
                <button onclick="updateCartQty(${item.id}, 0)" class="text-rose-500 hover:text-rose-600 p-1">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
            </div>
        `;
    }).join('');

    subtotalEl.innerText = formatPrice(subtotal);
    lucide.createIcons();
}

// Wishlist & Compare
function toggleWishlist(productId) {
    const idx = state.wishlist.indexOf(productId);
    if (idx > -1) {
        state.wishlist.splice(idx, 1);
    } else {
        state.wishlist.push(productId);
    }
    saveState();
    updateBadges();
    renderApp();
}

function toggleCompare(productId) {
    const idx = state.compare.indexOf(productId);
    if (idx > -1) {
        state.compare.splice(idx, 1);
    } else {
        if (state.compare.length >= 3) {
            alert("You can compare maximum 3 items simultaneously.");
            return;
        }
        state.compare.push(productId);
    }
    saveState();
    updateBadges();
    renderApp();
}

// Quick View Modal
function openQuickView(productId) {
    const product = state.products.find(p => p.id === productId);
    if (!product) return;

    const modal = document.getElementById('quickview-modal');
    const content = document.getElementById('quickview-content');

    content.innerHTML = `
        <button onclick="closeQuickView()" class="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-white p-2">
            <i data-lucide="x" class="w-6 h-6"></i>
        </button>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <img src="${product.image}" class="w-full h-80 object-cover rounded-2xl shadow-lg">
            <div class="space-y-4">
                <span class="text-xs font-bold text-amber-500 uppercase tracking-widest">${product.brand}</span>
                <h3 class="text-2xl font-bold">${product.name}</h3>
                <div class="flex items-center gap-3">
                    <span class="text-2xl font-extrabold text-amber-500">${formatPrice(product.discountBDT)}</span>
                    <span class="text-sm text-slate-400 line-through">${formatPrice(product.priceBDT)}</span>
                </div>
                <p class="text-sm text-slate-500 dark:text-slate-400">${product.description}</p>
                <div class="space-y-1 text-xs">
                    ${Object.entries(product.specs || {}).map(([k, v]) => `<div><span class="font-bold text-slate-400">${k}:</span> ${v}</div>`).join('')}
                </div>
                <div class="flex gap-3 pt-4">
                    <button onclick="addToCart(${product.id}); closeQuickView();" ${!product.inStock ? 'disabled' : ''} class="flex-1 py-3 bg-amber-500 hover:bg-amber-600 disabled:bg-slate-700 text-slate-950 font-bold rounded-xl transition shadow-lg shadow-amber-500/20">
                        ${product.inStock ? 'Add to Cart' : 'Out of Stock'}
                    </button>
                </div>
            </div>
        </div>
    `;

    modal.classList.remove('hidden');
    lucide.createIcons();
}

function closeQuickView() {
    document.getElementById('quickview-modal').classList.add('hidden');
}

// Dynamic View Renderer
function renderApp() {
    const main = document.getElementById('app-container');

    if (state.view === 'home') {
        const categories = ['All', 'Fashion', 'Electronics', 'Beauty', 'Accessories', 'Home & Lifestyle'];
        const filteredProducts = state.activeCategory === 'All' 
            ? state.products 
            : state.products.filter(p => p.category === state.activeCategory);

        main.innerHTML = `
            <!-- Hero Section -->
            <div class="relative rounded-3xl overflow-hidden bg-slate-900 text-white p-8 sm:p-16 mb-12 shadow-2xl border border-slate-800">
                <div class="absolute inset-0 opacity-40 bg-cover bg-center" style="background-image: url('https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1600');"></div>
                <div class="relative z-10 max-w-2xl space-y-6 animate-fade-in">
                    <span class="bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest">Autumn Luxury Drop 2026</span>
                    <h1 class="text-4xl sm:text-6xl font-extrabold tracking-tight leading-tight">Crafted For The Modern Connoisseur.</h1>
                    <p class="text-slate-300 text-base sm:text-lg">Discover exclusive apparel, high-fidelity audio, and artisanal lifestyle essentials shipped across Bangladesh.</p>
                    <div class="flex gap-4 pt-4">
                        <button onclick="document.getElementById('product-grid').scrollIntoView({ behavior: 'smooth' })" class="px-8 py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl shadow-lg shadow-amber-500/20 transition">Explore Collection</button>
                    </div>
                </div>
            </div>

            <!-- Categories Bar -->
            <div id="product-grid" class="flex items-center gap-2 overflow-x-auto pb-4 mb-8">
                ${categories.map(cat => `
                    <button onclick="filterCategory('${cat}')" class="px-5 py-2.5 rounded-full text-sm font-semibold transition whitespace-nowrap ${state.activeCategory === cat ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}">
                        ${cat}
                    </button>
                `).join('')}
            </div>

            <!-- Products Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                ${filteredProducts.map(p => {
                    const isWish = state.wishlist.includes(p.id);
                    const isComp = state.compare.includes(p.id);
                    return `
                        <div class="group bg-white dark:bg-slate-850 rounded-3xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
                            <div>
                                <div class="relative rounded-2xl overflow-hidden mb-4 aspect-square bg-slate-100 dark:bg-slate-800">
                                    <img src="${p.image}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                                    <div class="absolute top-3 right-3 flex flex-col gap-2">
                                        <button onclick="toggleWishlist(${p.id})" class="p-2.5 rounded-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-md text-slate-700 dark:text-slate-200 hover:text-rose-500 transition shadow">
                                            <i data-lucide="heart" class="w-4 h-4 ${isWish ? 'fill-rose-500 text-rose-500' : ''}"></i>
                                        </button>
                                        <button onclick="toggleCompare(${p.id})" class="p-2.5 rounded-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-md text-slate-700 dark:text-slate-200 hover:text-amber-500 transition shadow">
                                            <i data-lucide="sliders" class="w-4 h-4 ${isComp ? 'text-amber-500' : ''}"></i>
                                        </button>
                                    </div>
                                    <span class="absolute bottom-3 left-3 bg-slate-950/70 backdrop-blur-md text-amber-400 text-[10px] font-extrabold px-2.5 py-1 rounded-md uppercase tracking-wider">${p.brand}</span>
                                </div>
                                <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
                                    <span>${p.category}</span>
                                    <span class="flex items-center gap-1 text-amber-400 font-bold"><i data-lucide="star" class="w-3 h-3 fill-amber-400"></i> ${p.rating} (${p.reviewsCount})</span>
                                </div>
                                <h3 onclick="openQuickView(${p.id})" class="text-base font-bold text-slate-800 dark:text-slate-100 hover:text-amber-500 cursor-pointer line-clamp-1 mb-2">${p.name}</h3>
                            </div>
                            <div>
                                <div class="flex items-baseline gap-2 mb-4">
                                    <span class="text-xl font-extrabold text-amber-500">${formatPrice(p.discountBDT)}</span>
                                    <span class="text-xs text-slate-400 line-through">${formatPrice(p.priceBDT)}</span>
                                </div>
                                <button onclick="addToCart(${p.id})" ${!p.inStock ? 'disabled' : ''} class="w-full py-3 bg-slate-900 dark:bg-slate-800 hover:bg-amber-500 hover:text-slate-950 disabled:bg-slate-200 text-white font-bold rounded-xl transition flex items-center justify-center gap-2 text-sm shadow">
                                    <i data-lucide="shopping-bag" class="w-4 h-4"></i> ${p.inStock ? 'Add to Bag' : 'Out of Stock'}
                                </button>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    } else if (state.view === 'checkout') {
        let subtotal = state.cart.reduce((sum, item) => sum + (item.discountBDT * item.quantity), 0);
        let shipping = subtotal > 10000 || subtotal === 0 ? 0 : 120;
        let total = subtotal + shipping - state.discountAmount;

        main.innerHTML = `
            <div class="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-10">
                <div class="space-y-6 bg-white dark:bg-slate-850 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
                    <h2 class="text-xl font-bold flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-4">
                        <i data-lucide="truck" class="text-amber-500"></i> Delivery & Payment Details
                    </h2>
                    <form onsubmit="handlePlaceOrder(event)" class="space-y-4 text-sm">
                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Full Name</label>
                            <input required type="text" placeholder="Tanvir Ahmed" class="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Phone Number (bKash/Nagad Compatible)</label>
                            <input required type="tel" placeholder="+880 1712 345678" class="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Shipping Address</label>
                            <textarea required placeholder="House 42, Road 11, Banani, Dhaka" class="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500"></textarea>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Payment Method</label>
                            <select class="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500 font-semibold">
                                <option>Cash on Delivery (COD)</option>
                                <option>bKash Online Payment</option>
                                <option>Nagad Direct Pay</option>
                                <option>Credit / Debit Card</option>
                            </select>
                        </div>
                        <button type="submit" ${state.cart.length === 0 ? 'disabled' : ''} class="w-full py-4 bg-amber-500 hover:bg-amber-600 disabled:bg-slate-700 text-slate-950 font-bold rounded-xl transition shadow-lg shadow-amber-500/20 text-base mt-4">
                            Confirm Order (${formatPrice(total)})
                        </button>
                    </form>
                </div>
                <div class="bg-slate-100 dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-6">
                    <h3 class="text-lg font-bold border-b border-slate-200 dark:border-slate-800 pb-3">Order Summary</h3>
                    <div class="space-y-3 max-h-60 overflow-y-auto pr-2">
                        ${state.cart.map(i => `
                            <div class="flex justify-between items-center text-xs">
                                <div>
                                    <div class="font-bold text-slate-800 dark:text-slate-100">${i.name}</div>
                                    <div class="text-slate-400">Qty: ${i.quantity}</div>
                                </div>
                                <div class="font-bold text-amber-500">${formatPrice(i.discountBDT * i.quantity)}</div>
                            </div>
                        `).join('')}
                    </div>
                    <div class="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2 text-sm">
                        <div class="flex justify-between text-slate-400"><span>Subtotal</span><span>${formatPrice(subtotal)}</span></div>
                        <div class="flex justify-between text-slate-400"><span>Delivery Charge</span><span>${shipping === 0 ? 'FREE' : formatPrice(shipping)}</span></div>
                        ${state.discountAmount > 0 ? `<div class="flex justify-between text-emerald-500 font-bold"><span>Promo Discount</span><span>-${formatPrice(state.discountAmount)}</span></div>` : ''}
                        <div class="flex justify-between text-base font-extrabold pt-2 border-t border-slate-200 dark:border-slate-800"><span>Total</span><span class="text-amber-500">${formatPrice(total)}</span></div>
                    </div>
                </div>
            </div>
        `;
    } else if (state.view === 'compare') {
        const compareItems = state.products.filter(p => state.compare.includes(p.id));
        main.innerHTML = `
            <div class="space-y-6">
                <h2 class="text-2xl font-bold flex items-center gap-2">Product Comparison Matrix</h2>
                ${compareItems.length === 0 ? `
                    <div class="text-center py-20 text-slate-400">
                        <p>No items selected for comparison. Click the comparison icon on product cards to add.</p>
                    </div>
                ` : `
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr>
                                    <th class="p-4 bg-slate-100 dark:bg-slate-800">Feature</th>
                                    ${compareItems.map(item => `
                                        <th class="p-4 bg-slate-50 dark:bg-slate-850 min-w-[200px]">
                                            <img src="${item.image}" class="w-20 h-20 object-cover rounded-xl mb-2">
                                            <div class="font-bold text-sm">${item.name}</div>
                                            <div class="text-amber-500 text-xs font-bold">${formatPrice(item.discountBDT)}</div>
                                        </th>
                                    `).join('')}
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-200 dark:divide-slate-800 text-sm">
                                <tr>
                                    <td class="p-4 font-bold text-slate-400">Category</td>
                                    ${compareItems.map(item => `<td class="p-4">${item.category}</td>`).join('')}
                                </tr>
                                <tr>
                                    <td class="p-4 font-bold text-slate-400">Brand</td>
                                    ${compareItems.map(item => `<td class="p-4">${item.brand}</td>`).join('')}
                                </tr>
                                <tr>
                                    <td class="p-4 font-bold text-slate-400">Rating</td>
                                    ${compareItems.map(item => `<td class="p-4">⭐ ${item.rating}</td>`).join('')}
                                </tr>
                            </tbody>
                        </table>
                    </div>
                `}
            </div>
        `;
    } else if (state.view === 'admin') {
        main.innerHTML = `
            <div class="space-y-8 animate-fade-in">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="text-2xl font-bold">Admin Management Suite</h2>
                        <p class="text-xs text-slate-400">Live inventory and metric analytics overview.</p>
                    </div>
                    <button onclick="createNewProductPrompt()" class="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-sm flex items-center gap-2">
                        <i data-lucide="plus"></i> Add New Product
                    </button>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    <div class="bg-white dark:bg-slate-850 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
                        <div class="text-xs font-bold text-slate-400 uppercase">Total Inventory Items</div>
                        <div class="text-3xl font-extrabold text-amber-500 mt-2">${state.products.length}</div>
                    </div>
                    <div class="bg-white dark:bg-slate-850 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
                        <div class="text-xs font-bold text-slate-400 uppercase">Simulated Gross Revenue</div>
                        <div class="text-3xl font-extrabold text-emerald-500 mt-2">৳4,85,000</div>
                    </div>
                    <div class="bg-white dark:bg-slate-850 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
                        <div class="text-xs font-bold text-slate-400 uppercase">Active Currencies</div>
                        <div class="text-3xl font-extrabold text-indigo-500 mt-2">BDT & USD</div>
                    </div>
                </div>

                <div class="bg-white dark:bg-slate-850 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden">
                    <table class="w-full text-left border-collapse">
                        <thead class="bg-slate-100 dark:bg-slate-800 text-xs text-slate-400 uppercase">
                            <tr>
                                <th class="p-4">Product</th>
                                <th class="p-4">Category</th>
                                <th class="p-4">Price (BDT)</th>
                                <th class="p-4">Status</th>
                                <th class="p-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-800 text-sm">
                            ${state.products.map(p => `
                                <tr>
                                    <td class="p-4 flex items-center gap-3">
                                        <img src="${p.image}" class="w-10 h-10 object-cover rounded-lg">
                                        <span class="font-bold">${p.name}</span>
                                    </td>
                                    <td class="p-4">${p.category}</td>
                                    <td class="p-4 font-bold text-amber-500">${formatPrice(p.discountBDT)}</td>
                                    <td class="p-4"><span class="px-2 py-1 rounded text-xs font-bold ${p.inStock ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}">${p.inStock ? 'In Stock' : 'Out of Stock'}</span></td>
                                    <td class="p-4 text-right">
                                        <button onclick="deleteProduct(${p.id})" class="text-rose-500 hover:text-rose-700 p-2"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    lucide.createIcons();
}

function handlePlaceOrder(e) {
    e.preventDefault();
    const orderId = 'LX-' + Math.floor(100000 + Math.random() * 900000);
    alert(`Success! Order #${orderId} has been placed. Details sent to your contact info.`);
    state.cart = [];
    saveState();
    updateBadges();
    navigateTo('home');
}

function deleteProduct(id) {
    if (confirm("Are you sure you want to delete this product?")) {
        state.products = state.products.filter(p => p.id !== id);
        saveState();
        renderApp();
    }
}

function createNewProductPrompt() {
    const name = prompt("Enter product name:");
    if (!name) return;
    const price = parseInt(prompt("Enter price in BDT (e.g. 15000):") || "10000");
    const category = prompt("Category (Fashion, Electronics, Beauty, Home & Lifestyle):") || "Fashion";

    const newProd = {
        id: Date.now(),
        name,
        category,
        brand: "Luxe Custom",
        priceBDT: price,
        priceUSD: Math.round(price / USD_RATE),
        discountBDT: price,
        discountUSD: Math.round(price / USD_RATE),
        rating: 5.0,
        reviewsCount: 1,
        inStock: true,
        image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800",
        description: "Newly added custom item to LuxeMarket catalogue.",
        specs: { Origin: "Custom Import" }
    };

    state.products.unshift(newProd);
    saveState();
    renderApp();
}
